# HtmlUnit - Jenkins pipelines

Overview
--------
All the different build jobs are based on jenkins pipeline scripts and all the scripts are located in the scr/jenkins directory.

Scripts
--------
* jenkinsfile - the script for the main build job - runs on every commit

* huge-tests-a-c, huge-tests-d-g, huge-tests-h-l, huge-tests-m-o, huge-tests-p-r, huge-tests-s, huge-tests-t-z, huge-tests-element-closes-element - the various scripts for the huge jobs running once per day

