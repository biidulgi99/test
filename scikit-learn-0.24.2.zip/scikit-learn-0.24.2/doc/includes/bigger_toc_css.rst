..  
    File to ..include in a document with a very big table of content, to 
    give it 'style'

.. raw:: html

  <style type="text/css">
    div.bodywrapper blockquote {
        margin: 0 ;
    }

    div.toctree-wrapper ul {
	margin: 0 ;
	padding-left: 0px ;
    }

    li.toctree-l1 {
        padding: 0 ;
        list-style-type: none;
        font-size: 150% ;
	font-family: Arial, sans-serif;
	background-color: #BED4EB;
	font-weight: normal;
	color: #212224;
	margin-left : 0;
	font-weight: bold;
        }

    li.toctree-l1 a {
        padding: 0 0 0 10px ;
    }
 
    li.toctree-l2 {
        padding: 0.25em 0 0.25em 0 ;
        list-style-type: none;
	background-color: #FFFFFF;
        font-size: 90% ;
	font-weight: bold;
        }

    li.toctree-l2 ul {
	padding-left: 40px ;
    }

    li.toctree-l3 {
        font-size: 70% ;
        list-style-type: none;
	font-weight: normal;
        }

    li.toctree-l4 {
        font-size: 85% ;
        list-style-type: none;
	font-weight: normal;
        }
 
  </style>



