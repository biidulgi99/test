---
name: Feature / Enhancement Request
about: Adding new features or improving existing ones.
title: 'IMPORTANT: This repository no longer accepts feature / enhancement requests.'
labels: ''
assignees: ''

---

**IMPORTANT, PLEASE READ**

Feature / Enhancement requests are no longer accepted in the main Godot repository.
Please open an item by filling the relevant fields in the *Proposals* repository:

https://github.com/godotengine/godot-proposals/issues/new/choose

Do not submit to this repository or your issue will be closed.

**IMPORTANT, PLEASE READ**
